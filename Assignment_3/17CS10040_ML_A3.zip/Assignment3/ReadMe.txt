Execute all the files in Order using python3 Task1->Task2->Task3->Task4->Task5
After Each execution, you will see a new file is created in data folder, corresponding to task.
Final NMI Scores will displayed on terminal in the similar fashion as it is displayed below


NMI SCORES:
For Agglomerative Clustering
NMI for the Given Clustering:  1.8797709959742241
For KMeans Clustering
NMI for the Given Clustering:  0.5174242794409872
For Agglomerative Clustering after PCA
NMI for the Given Clustering:  1.8730156131841977
For KMeans After PCA
NMI for the Given Clustering:  0.2540218934465006
